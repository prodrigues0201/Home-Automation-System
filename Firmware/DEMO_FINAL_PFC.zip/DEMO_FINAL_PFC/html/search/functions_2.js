var searchData=
[
  ['ldrtolumens_0',['LdrToLumens',['../_d_e_m_o___f_i_n_a_l___p_f_c_8ino.html#a4587305c5e3328987c87351955906dd7',1,'DEMO_FINAL_PFC.ino']]],
  ['loop_1',['loop',['../_d_e_m_o___f_i_n_a_l___p_f_c_8ino.html#afe461d27b9c48d5921c00d521181f12f',1,'DEMO_FINAL_PFC.ino']]]
];
