var searchData=
[
  ['gethumidity_0',['getHumidity',['../class_my_d_h_t11.html#a5dcc986187e632d05298aa6b91b02075',1,'MyDHT11']]],
  ['gettemperature_1',['getTemperature',['../class_my_d_h_t11.html#aeee60d6eb235c6f23d6e4916fbee7ecf',1,'MyDHT11']]]
];
