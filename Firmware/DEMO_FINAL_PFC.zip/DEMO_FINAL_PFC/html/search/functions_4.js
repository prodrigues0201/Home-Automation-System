var searchData=
[
  ['publishalldata_0',['publishAllData',['../_d_e_m_o___f_i_n_a_l___p_f_c_8ino.html#a179e3a154ceef526bc46d27e8144fb5e',1,'DEMO_FINAL_PFC.ino']]],
  ['pzem_1',['pzem',['../_d_e_m_o___f_i_n_a_l___p_f_c_8ino.html#a1110110145fe4d565e2b4721e713b30e',1,'DEMO_FINAL_PFC.ino']]]
];
