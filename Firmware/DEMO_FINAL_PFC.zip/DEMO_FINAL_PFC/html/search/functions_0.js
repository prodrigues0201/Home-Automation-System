var searchData=
[
  ['callback_0',['callback',['../_d_e_m_o___f_i_n_a_l___p_f_c_8ino.html#ac3a129f66dc859e2b7279565f4e1de78',1,'DEMO_FINAL_PFC.ino']]],
  ['client_1',['client',['../_d_e_m_o___f_i_n_a_l___p_f_c_8ino.html#aee63e84c606cfaefce454689113c636c',1,'DEMO_FINAL_PFC.ino']]]
];
