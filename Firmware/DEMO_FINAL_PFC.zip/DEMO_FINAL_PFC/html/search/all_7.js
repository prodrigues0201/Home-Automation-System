var searchData=
[
  ['ldr_0',['ldr',['../_d_e_m_o___f_i_n_a_l___p_f_c_8ino.html#a8246fafdfedfd47733a2238530b4afca',1,'DEMO_FINAL_PFC.ino']]],
  ['ldrpin_1',['LDRPIN',['../_d_e_m_o___f_i_n_a_l___p_f_c_8ino.html#a7b9f8130aa86fd9296d46ad818e1d2da',1,'DEMO_FINAL_PFC.ino']]],
  ['ldrtolumens_2',['LdrToLumens',['../_d_e_m_o___f_i_n_a_l___p_f_c_8ino.html#a4587305c5e3328987c87351955906dd7',1,'DEMO_FINAL_PFC.ino']]],
  ['ledpin_3',['LEDPIN',['../_d_e_m_o___f_i_n_a_l___p_f_c_8ino.html#a2b3671e090b0831bfba7d12cfcf2d481',1,'DEMO_FINAL_PFC.ino']]],
  ['loop_4',['loop',['../_d_e_m_o___f_i_n_a_l___p_f_c_8ino.html#afe461d27b9c48d5921c00d521181f12f',1,'DEMO_FINAL_PFC.ino']]],
  ['lumens_5',['lumens',['../_d_e_m_o___f_i_n_a_l___p_f_c_8ino.html#a2b2777bd54c29b810f8c201cdd30094d',1,'DEMO_FINAL_PFC.ino']]],
  ['luz_6',['luz',['../_d_e_m_o___f_i_n_a_l___p_f_c_8ino.html#a361d9560a5d2b91fded39e22d14764e4',1,'DEMO_FINAL_PFC.ino']]]
];
