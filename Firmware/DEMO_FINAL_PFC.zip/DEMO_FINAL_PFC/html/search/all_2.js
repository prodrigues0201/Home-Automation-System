var searchData=
[
  ['energy_0',['energy',['../_d_e_m_o___f_i_n_a_l___p_f_c_8ino.html#a2d107b3b2dcebab8a10c9d39894f6b2a',1,'DEMO_FINAL_PFC.ino']]],
  ['espclient_1',['espClient',['../_d_e_m_o___f_i_n_a_l___p_f_c_8ino.html#abd77e757e4b3bb6f1e4b42b21ea9e040',1,'DEMO_FINAL_PFC.ino']]]
];
