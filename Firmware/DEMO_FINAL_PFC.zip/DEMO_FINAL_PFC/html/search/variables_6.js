var searchData=
[
  ['ldr_0',['ldr',['../_d_e_m_o___f_i_n_a_l___p_f_c_8ino.html#a8246fafdfedfd47733a2238530b4afca',1,'DEMO_FINAL_PFC.ino']]],
  ['lumens_1',['lumens',['../_d_e_m_o___f_i_n_a_l___p_f_c_8ino.html#a2b2777bd54c29b810f8c201cdd30094d',1,'DEMO_FINAL_PFC.ino']]],
  ['luz_2',['luz',['../_d_e_m_o___f_i_n_a_l___p_f_c_8ino.html#a361d9560a5d2b91fded39e22d14764e4',1,'DEMO_FINAL_PFC.ino']]]
];
