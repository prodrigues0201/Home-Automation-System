var searchData=
[
  ['setup_0',['setup',['../_d_e_m_o___f_i_n_a_l___p_f_c_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'DEMO_FINAL_PFC.ino']]],
  ['setup_5fwifi_1',['setup_wifi',['../_d_e_m_o___f_i_n_a_l___p_f_c_8ino.html#ae5b88d967e3185d98053cf055c8b4f1f',1,'DEMO_FINAL_PFC.ino']]]
];
