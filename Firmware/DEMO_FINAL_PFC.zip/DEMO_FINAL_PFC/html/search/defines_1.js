var searchData=
[
  ['ldrpin_0',['LDRPIN',['../_d_e_m_o___f_i_n_a_l___p_f_c_8ino.html#a7b9f8130aa86fd9296d46ad818e1d2da',1,'DEMO_FINAL_PFC.ino']]],
  ['ledpin_1',['LEDPIN',['../_d_e_m_o___f_i_n_a_l___p_f_c_8ino.html#a2b3671e090b0831bfba7d12cfcf2d481',1,'DEMO_FINAL_PFC.ino']]]
];
